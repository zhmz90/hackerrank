# hackerrank
code while play on hackerrank 
